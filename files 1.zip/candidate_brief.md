# Streamlit Dashboard Challenge

## Context

You're a data analyst at a professional sports league. The marketing team spends money on **4 channels** (TV, Digital, Social, Audio) to drive game viewership. A modeling team has already figured out how much viewership each channel drove per game. Your job: **build a 2-page Streamlit dashboard** that helps the marketing team understand what's working.

---

## Key Concept: Contribution

Every game has a total viewership number (in millions). It breaks down like this:

**Total Viewership = Base Viewership + TV Contribution + Digital Contribution + Social Contribution + Audio Contribution**

- **Base viewership** = viewers who would have watched regardless of marketing
- **Channel contribution** = extra viewers driven by that channel's marketing spend

This is already computed for you — you don't need to model anything.

There's also a **response curve** for each channel (see `response_curves.csv` and the reference image). It shows: as you spend more, you get more viewers — but with diminishing returns. The curve flattens out as a channel gets "saturated."

---

## Your Files

**`game_data.csv`** — 328 games, one row per game

| Column | What it is |
|--------|-----------|
| `game_id`, `date`, `day_of_week` | Game identifiers |
| `time_slot` | Afternoon / Prime Time / Late Night |
| `home_team`, `away_team` | Team names |
| `marquee_game` | 1 = high-profile game, 0 = regular |
| `tv_spend`, `digital_spend`, `social_spend`, `audio_spend` | Dollars spent per channel |
| `tv_contribution`, `digital_contribution`, `social_contribution`, `audio_contribution` | Viewers (millions) driven by each channel |
| `base_viewership` | Organic viewers (millions) |
| `total_spend` | Sum of all channel spend |
| `total_viewership` | Base + all contributions (millions) |

**`response_curves.csv`** — 30 points per channel showing spend vs. viewership contribution

**`response_curve_reference.png`** — Visual explainer of how a response curve works (for your reference, not required to recreate)

---

## What to Build

**Page 1 — Overview**: How is viewership performing? What's driving it? Think: totals, trends over time, channel breakdown, how game factors (time slot, marquee games, day of week) affect viewership.

**Page 2 — Channel Deep Dive**: How is each channel performing? Plot the response curves. Where are we spending efficiently vs. overspending?

Include **3–5 bullet points of insight** somewhere in the dashboard — what would you tell a marketing executive based on this data?

---

## Rules

- **Time:** ~2 hours
- **Stack:** Streamlit, any Python libraries
- **AI tools:** Allowed — we care about the output, not how you got there
- **Max 2 pages**

## What We're Evaluating

- Does the dashboard tell a clear story?
- Are the chart choices sensible?
- Would a non-technical person understand it?
- Are the insights specific and useful (not generic)?
